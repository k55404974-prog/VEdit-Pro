import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';

void main() => runApp(const VEditPro());

enum TrackType { video, overlay, text, audio }

extension TrackTypeLabel on TrackType {
  String get label => switch (this) {
        TrackType.video => 'Video',
        TrackType.overlay => 'Overlay',
        TrackType.text => 'Text',
        TrackType.audio => 'Audio',
      };
  IconData get icon => switch (this) {
        TrackType.video => Icons.movie_outlined,
        TrackType.overlay => Icons.layers_outlined,
        TrackType.text => Icons.text_fields,
        TrackType.audio => Icons.music_note_outlined,
      };
}

class VEditPro extends StatelessWidget {
  const VEditPro({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'VEdit Pro',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: const Color(0xFF0B0B10),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8B5CF6),
            brightness: Brightness.dark,
          ),
        ),
        home: const EditorPage(),
      );
}

class Clip {
  Clip({
    required this.path,
    required this.name,
    required this.isVideo,
    required this.sourceDuration,
    this.track = TrackType.video,
    Duration? start,
    Duration? end,
    this.volume = 1.0,
    this.fadeIn = 0.0,
    this.fadeOut = 0.0,
    this.brightness = 0.0,
    this.saturation = 1.0,
    this.rotation = 0,
    this.transition = 0.0,
    Duration? timelineStart,
  })  : start = start ?? Duration.zero,
        timelineStart = timelineStart ?? Duration.zero,
        end = end ?? sourceDuration;

  final String path;
  final String name;
  final bool isVideo;
  final Duration sourceDuration;
  final TrackType track;
  Duration start;
  Duration end;
  Duration timelineStart;
  Duration get duration => end - start;
  double volume;
  double fadeIn;
  double fadeOut;
  double brightness;
  double saturation;
  int rotation;
  double transition;

  Clip copyWith({
    Duration? start,
    Duration? end,
    String? name,
    TrackType? track,
    double? volume,
    double? fadeIn,
    double? fadeOut,
    double? brightness,
    double? saturation,
    int? rotation,
    double? transition,
    Duration? timelineStart,
  }) => Clip(
        path: path,
        name: name ?? this.name,
        isVideo: isVideo,
        sourceDuration: sourceDuration,
        track: track ?? this.track,
        start: start ?? this.start,
        end: end ?? this.end,
        volume: volume ?? this.volume,
        fadeIn: fadeIn ?? this.fadeIn,
        fadeOut: fadeOut ?? this.fadeOut,
        brightness: brightness ?? this.brightness,
        saturation: saturation ?? this.saturation,
        rotation: rotation ?? this.rotation,
        transition: transition ?? this.transition,
        timelineStart: timelineStart ?? this.timelineStart,
      );
}


class TextItem {
  TextItem({required this.text, this.start = Duration.zero, required this.end, this.x = 0.5, this.y = 0.5, this.fontSize = 30});
  String text;
  Duration start;
  Duration end;
  double x;
  double y;
  double fontSize;

  TextItem copyWith({String? text, Duration? start, Duration? end, double? x, double? y, double? fontSize}) => TextItem(
    text: text ?? this.text,
    start: start ?? this.start,
    end: end ?? this.end,
    x: x ?? this.x,
    y: y ?? this.y,
    fontSize: fontSize ?? this.fontSize,
  );
}

class Snapshot {
  const Snapshot(this.clips, this.selected, this.track, this.zoom, this.snap, this.markers, this.textItems);
  final List<Clip> clips;
  final int selected;
  final TrackType track;
  final double zoom;
  final bool snap;
  final List<Duration> markers;
  final List<TextItem> textItems;
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  String _projectName = 'Untitled Project';
  final List<Clip> clips = [];
  final List<Snapshot> undo = [];
  final List<Snapshot> redo = [];
  final List<Duration> markers = [];
  int selected = -1;
  TrackType selectedTrack = TrackType.video;
  bool snapEnabled = true;
  double timelineZoom = 1.0;
  VideoPlayerController? player;
  final AudioPlayer audioPlayer = AudioPlayer();
  final List<TextItem> textItems = [];
  String? _loadedProjectPath;
  bool _rendering = false;
  double _renderProgress = 0;
  String _renderStatus = '';
  int? _renderSessionId;
  final ValueNotifier<double> _renderProgressNotifier = ValueNotifier(0);
  final ValueNotifier<String> _renderStatusNotifier = ValueNotifier('');

  Clip? get current => selected >= 0 && selected < clips.length ? clips[selected] : null;

  Duration get timelineDuration {
    if (clips.isEmpty) return Duration.zero;
    var maxEnd = Duration.zero;
    for (final c in clips) {
      if (c.track == TrackType.video || c.track == TrackType.overlay || c.track == TrackType.audio) {
        final end = c.timelineStart + c.duration;
        if (end > maxEnd) maxEnd = end;
      }
    }
    return maxEnd > Duration.zero ? maxEnd : const Duration(seconds: 1);
  }

  void history() {
    undo.add(Snapshot(
      clips.map((c) => c.copyWith()).toList(),
      selected,
      selectedTrack,
      timelineZoom,
      snapEnabled,
      List.of(markers),
      textItems.map((t) => t.copyWith()).toList(),
    ));
    redo.clear();
  }

  Future<void> _renameProject() async {
    final controller = TextEditingController(text: _projectName);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Project'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Project name'),
          onSubmitted: (v) => Navigator.pop(context, v.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.trim().isNotEmpty) {
      history();
      setState(() => _projectName = value.trim());
    }
  }

  Future<void> importMedia() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.media);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    final name = result.files.single.name;
    final video = RegExp(r'\.(mp4|mov|m4v|webm|mkv)$', caseSensitive: false).hasMatch(path);

    if (!video) {
      history();
      setState(() {
        clips.add(Clip(
          path: path,
          name: name,
          isVideo: false,
          sourceDuration: const Duration(seconds: 5),
          track: selectedTrack == TrackType.text ? TrackType.overlay : selectedTrack,
          timelineStart: timelineDuration,
        ));
        selected = clips.length - 1;
      });
      return;
    }

    final controller = VideoPlayerController.file(File(path));
    await controller.initialize();
    await player?.dispose();
    history();
    setState(() {
      player = controller;
      clips.add(Clip(
        path: path,
        name: name,
        isVideo: true,
        sourceDuration: controller.value.duration,
        track: selectedTrack == TrackType.video ? TrackType.video : selectedTrack,
        timelineStart: timelineDuration,
      ));
      selected = clips.length - 1;
    });
  }

  Future<void> loadPreview() async {
    await audioPlayer.stop();
    final c = current;
    if (c == null || !c.isVideo) return;
    final controller = VideoPlayerController.file(File(c.path));
    await controller.initialize();
    await player?.dispose();
    if (!mounted) {
      await controller.dispose();
      return;
    }
    setState(() => player = controller);
  }

  void undoAction() {
    if (undo.isEmpty) return;
    redo.add(_snapshot());
    final s = undo.removeLast();
    _restore(s);
  }

  void redoAction() {
    if (redo.isEmpty) return;
    undo.add(_snapshot());
    final s = redo.removeLast();
    _restore(s);
  }

  Snapshot _snapshot() => Snapshot(
        clips.map((c) => c.copyWith()).toList(),
        selected,
        selectedTrack,
        timelineZoom,
        snapEnabled,
        List.of(markers),
        textItems.map((t) => t.copyWith()).toList(),
      );

  void _restore(Snapshot s) {
    setState(() {
      clips
        ..clear()
        ..addAll(s.clips.map((c) => c.copyWith()));
      selected = s.selected;
      selectedTrack = s.track;
      timelineZoom = s.zoom;
      snapEnabled = s.snap;
      markers
        ..clear()
        ..addAll(s.markers);
      textItems
        ..clear()
        ..addAll(s.textItems.map((t) => t.copyWith()));
    });
    loadPreview();
  }

  Duration snapTime(Duration value) {
    if (!snapEnabled) return value;
    final candidates = <Duration>[Duration.zero, ...markers];
    for (final c in clips) {
      candidates.add(c.timelineStart);
      candidates.add(c.timelineStart + c.duration);
    }
    const threshold = 180;
    Duration? best;
    var bestDistance = threshold + 1;
    for (final candidate in candidates) {
      final distance = (candidate - value).inMilliseconds.abs();
      if (distance <= threshold && distance < bestDistance) {
        best = candidate;
        bestDistance = distance;
      }
    }
    return best ?? value;
  }

  void split() {
    final c = current;
    if (c == null || c.duration < const Duration(seconds: 2)) return;
    final rawCut = c.start + Duration(milliseconds: c.duration.inMilliseconds ~/ 2);
    final cut = snapTime(rawCut);
    if (cut <= c.start || cut >= c.end) return;
    history();
    final a = c.copyWith(name: '${c.name} • A', end: cut);
    final b = c.copyWith(name: '${c.name} • B', start: cut, timelineStart: c.timelineStart + (cut - c.start));
    setState(() {
      clips..removeAt(selected)..insertAll(selected, [a, b]);
      selected++;
    });
  }

  void trimIn() {
    final c = current;
    if (c == null || c.duration <= const Duration(seconds: 1)) return;
    final next = snapTime(c.start + const Duration(milliseconds: 500));
    if (next >= c.end) return;
    history();
    setState(() => clips[selected] = c.copyWith(start: next));
  }

  void trimOut() {
    final c = current;
    if (c == null || c.duration <= const Duration(seconds: 1)) return;
    final next = snapTime(c.end - const Duration(milliseconds: 500));
    if (next <= c.start) return;
    history();
    setState(() => clips[selected] = c.copyWith(end: next));
  }

  void deleteSelected() {
    if (current == null) return;
    history();
    setState(() {
      clips.removeAt(selected);
      selected = clips.isEmpty ? -1 : selected.clamp(0, clips.length - 1);
    });
    loadPreview();
  }

  void duplicateSelected() {
    final c = current;
    if (c == null) return;
    history();
    setState(() {
      clips.insert(selected + 1, c.copyWith(name: '${c.name} • Copy', timelineStart: c.timelineStart + c.duration));
      selected++;
    });
  }


  void nudgeSelectedTimeline(int deltaMs) {
    final c = current;
    if (c == null) return;
    var next = c.timelineStart + Duration(milliseconds: deltaMs);
    if (next.isNegative) next = Duration.zero;
    next = snapTime(next);
    history();
    setState(() => c.timelineStart = next);
  }

  Future<void> setSelectedTimelineStart() async {
    final c = current;
    if (c == null) return;
    final controller = TextEditingController(text: (c.timelineStart.inMilliseconds / 1000).toStringAsFixed(2));
    final value = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Timeline Position'),
        content: TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Start time (seconds)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, double.tryParse(controller.text)), child: const Text('Set')),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.isNaN || value.isInfinite || value < 0) return;
    history();
    setState(() => c.timelineStart = snapTime(Duration(milliseconds: (value * 1000).round())));
  }

  void moveSelected(int delta) {
    if (selected < 0 || selected >= clips.length) return;
    final target = selected + delta;
    if (target < 0 || target >= clips.length) return;
    history();
    setState(() {
      final item = clips.removeAt(selected);
      clips.insert(target, item);
      selected = target;
    });
  }

  Future<void> editTextOverlay() async {
    final controller = TextEditingController(text: textItems.isNotEmpty ? textItems.last.text : 'Your text');
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Text Overlay'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'Enter text')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Add')),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.isEmpty) return;
    final start = current?.timelineStart ?? Duration.zero;
    final end = current == null ? start + const Duration(seconds: 5) : start + current!.duration;
    history();
    setState(() => textItems.add(TextItem(text: value, start: start, end: end)));
  }

  Future<void> toggleAudioPreview() async {
    final c = current;
    if (c == null || c.isVideo || c.track != TrackType.audio) return;
    try {
      if (audioPlayer.playing) {
        await audioPlayer.pause();
      } else {
        await audioPlayer.setFilePath(c.path);
        await audioPlayer.setClip(start: c.start, end: c.end);
        await audioPlayer.play();
      }
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Audio preview failed: $e')));
    }
  }

  Future<void> showAudioControls() async {
    final c = current;
    if (c == null || c.track != TrackType.audio) return;
    double volume = c.volume;
    double fadeIn = c.fadeIn;
    double fadeOut = c.fadeOut;
    history();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(builder: (context, setSheet) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Text('Volume ${(volume * 100).round()}%'),
          Slider(value: volume, onChanged: (v) { setSheet(() => volume = v); audioPlayer.setVolume(v); setState(() => c.volume = v); }),
          Text('Fade in ${fadeIn.toStringAsFixed(1)}s'),
          Slider(value: fadeIn, min: 0, max: 5, onChanged: (v) { setSheet(() => fadeIn = v); setState(() => c.fadeIn = v); }),
          Text('Fade out ${fadeOut.toStringAsFixed(1)}s'),
          Slider(value: fadeOut, min: 0, max: 5, onChanged: (v) { setSheet(() => fadeOut = v); setState(() => c.fadeOut = v); }),
          const SizedBox(height: 8),
          const Text('Fade values are stored for the clip; full mixed export will apply them in the render engine.', style: TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 8),
        ]),
      )),
    );
  }

  Future<void> showEffects() async {
    final c = current;
    if (c == null || !c.isVideo) return;
    double brightness = c.brightness;
    double saturation = c.saturation;
    int rotation = c.rotation;
    double transition = c.transition;
    history();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(builder: (context, setSheet) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Clip Effects — ${c.name}', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text('Brightness ${brightness.toStringAsFixed(2)}'),
          Slider(min: -1, max: 1, value: brightness, onChanged: (v) { setSheet(() => brightness = v); setState(() => c.brightness = v); }),
          Text('Saturation ${saturation.toStringAsFixed(2)}'),
          Slider(min: 0, max: 2, value: saturation, onChanged: (v) { setSheet(() => saturation = v); setState(() => c.saturation = v); }),
          Row(children: [
            const Text('Rotate'), const SizedBox(width: 12),
            DropdownButton<int>(value: rotation, items: const [0, 90, 180, 270].map((v) => DropdownMenuItem(value: v, child: Text('$v°'))).toList(), onChanged: (v) { if (v != null) { setSheet(() => rotation = v); setState(() => c.rotation = v); } }),
            const Spacer(),
            Text('Transition ${transition.toStringAsFixed(1)}s'),
          ]),
          Slider(min: 0, max: 1.5, value: transition, onChanged: (v) { setSheet(() => transition = v); setState(() => c.transition = v); }),
          const Text('Transition is applied between adjacent Video-track clips during MP4 export.', style: TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 8),
        ]),
      )),
    );
  }

  Future<void> openProject() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
    if (result == null || result.files.single.path == null) return;
    try {
      final file = File(result.files.single.path!);
      final data = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      final loadedClips = (data['clips'] as List? ?? []).map((raw) {
        final m = raw as Map<String, dynamic>;
        final duration = Duration(milliseconds: (m['sourceDurationMs'] as num? ?? 5000).toInt());
        return Clip(
          path: m['path'] as String? ?? '', name: m['name'] as String? ?? 'Clip',
          isVideo: m['isVideo'] as bool? ?? false, sourceDuration: duration,
          track: TrackType.values.firstWhere((t) => t.name == m['track'], orElse: () => TrackType.video),
          start: Duration(milliseconds: (m['startMs'] as num? ?? 0).toInt()),
          end: Duration(milliseconds: (m['endMs'] as num? ?? duration.inMilliseconds).toInt()),
          timelineStart: Duration(milliseconds: (m['timelineStartMs'] as num? ?? 0).toInt()),
          volume: (m['volume'] as num? ?? 1).toDouble().clamp(0, 1),
          fadeIn: (m['fadeIn'] as num? ?? 0).toDouble().clamp(0, 30),
          fadeOut: (m['fadeOut'] as num? ?? 0).toDouble().clamp(0, 30),
          brightness: (m['brightness'] as num? ?? 0).toDouble().clamp(-1, 1),
          saturation: (m['saturation'] as num? ?? 1).toDouble().clamp(0, 2),
          rotation: (m['rotation'] as num? ?? 0).toInt(),
          transition: (m['transition'] as num? ?? 0).toDouble().clamp(0, 1.5),
        );
      }).toList();
      final loadedTexts = (data['textItems'] as List? ?? []).map((raw) {
        final m = raw as Map<String, dynamic>;
        return TextItem(text: m['text'] as String? ?? '', start: Duration(milliseconds: (m['startMs'] as num? ?? 0).toInt()), end: Duration(milliseconds: (m['endMs'] as num? ?? 5000).toInt()), x: (m['x'] as num? ?? .5).toDouble(), y: (m['y'] as num? ?? .5).toDouble(), fontSize: (m['fontSize'] as num? ?? 30).toDouble());
      }).toList();
      await player?.dispose();
      await audioPlayer.stop();
      setState(() {
        clips..clear()..addAll(loadedClips);
        textItems..clear()..addAll(loadedTexts);
        markers..clear()..addAll((data['markersMs'] as List? ?? []).map((e) => Duration(milliseconds: (e as num).toInt())));
        _projectName = data['projectName'] as String? ?? 'Untitled Project';
        selected = (data['selected'] as num? ?? (loadedClips.isEmpty ? -1 : 0)).toInt().clamp(-1, loadedClips.length - 1);
        selectedTrack = TrackType.values.firstWhere((t) => t.name == data['selectedTrack'], orElse: () => TrackType.video);
        snapEnabled = data['snapEnabled'] as bool? ?? true;
        timelineZoom = (data['timelineZoom'] as num? ?? 1).toDouble().clamp(.6, 2.2);
        _loadedProjectPath = file.path;
      });
      await loadPreview();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Project opened')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open project: $e')));
    }
  }

  void addMarker() {
    final position = player?.value.isInitialized == true
        ? player!.value.position
        : (current?.start ?? Duration.zero);
    final safe = snapTime(position);
    if (markers.any((m) => (m - safe).inMilliseconds.abs() < 100)) return;
    history();
    setState(() {
      markers.add(safe);
      markers.sort((a, b) => a.compareTo(b));
    });
  }

  void removeMarker(Duration marker) {
    history();
    setState(() => markers.remove(marker));
  }

  Future<void> seekPreview(Duration position) async {
    final c = current;
    if (c == null || player == null || !player!.value.isInitialized) return;
    var safe = position;
    if (safe < c.start) safe = c.start;
    if (safe > c.end) safe = c.end;
    safe = snapTime(safe);
    if (safe < c.start) safe = c.start;
    if (safe > c.end) safe = c.end;
    await player!.seekTo(safe);
    if (mounted) setState(() {});
  }

  String _shellQuote(String value) => "'${value.replaceAll("'", "'\\''")}'";

  Future<void> _showRenderDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => ValueListenableBuilder<double>(
        valueListenable: _renderProgressNotifier,
        builder: (context, progress, _) => AlertDialog(
          title: Text(_rendering ? 'Rendering…' : 'Render finished'),
          content: ValueListenableBuilder<String>(
            valueListenable: _renderStatusNotifier,
            builder: (context, status, _) => SizedBox(
              width: 320,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                LinearProgressIndicator(value: progress.clamp(0.0, 1.0)),
                const SizedBox(height: 14),
                Text('${(progress * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text(status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 12)),
              ]),
            ),
          ),
          actions: [
            if (_rendering)
              TextButton.icon(
                onPressed: _renderSessionId == null ? null : () async {
                  await FFmpegKit.cancel(_renderSessionId!);
                  _renderStatusNotifier.value = 'Cancelling…';
                },
                icon: const Icon(Icons.stop_circle_outlined),
                label: const Text('Cancel'),
              )
            else
              FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
          ],
        ),
      ),
    );
  }

  Future<void> exportMp4({bool timelinePreview = false}) async {
    if (_rendering) return;
    final videoClips = clips.where((c) => c.isVideo && c.track == TrackType.video && c.duration > Duration.zero).toList()
      ..sort((a, b) => a.timelineStart.compareTo(b.timelineStart));
    if (videoClips.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add at least one video clip to the Video track first.')));
      return;
    }
    final dir = await getApplicationDocumentsDirectory();
    final renderDir = Directory('${dir.path}/vedit_render');
    if (!await renderDir.exists()) await renderDir.create(recursive: true);
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final output = timelinePreview
        ? '${renderDir.path}/timeline_preview.mp4'
        : '${dir.path}/${_projectName.replaceAll(RegExp(r'[^a-zA-Z0-9_-]+'), '_')}_$stamp.mp4';
    final totalMs = timelineDuration.inMilliseconds.clamp(1, 24 * 60 * 60 * 1000);
    try {
      setState(() { _rendering = true; _renderProgress = 0; _renderStatus = timelinePreview ? 'Building multi-track preview…' : 'Preparing final MP4…'; _renderSessionId = null; });
      _renderProgressNotifier.value = 0;
      _renderStatusNotifier.value = _renderStatus;
      // Give the modal a frame to appear before FFmpeg starts.
      unawaited(_showRenderDialog());

      final args = <String>['-y', '-hide_banner'];
      final filters = <String>[];
      for (var i = 0; i < videoClips.length; i++) {
        final c = videoClips[i];
        final vf = <String>[
          'scale=1280:720:force_original_aspect_ratio=decrease',
          'pad=1280:720:(ow-iw)/2:(oh-ih)/2',
          'eq=brightness=${c.brightness.toStringAsFixed(4)}:saturation=${c.saturation.toStringAsFixed(4)}',
        ];
        if (c.rotation == 90) vf.add('transpose=1');
        if (c.rotation == 180) vf.add('transpose=1,transpose=1');
        if (c.rotation == 270) vf.add('transpose=2');
        vf.add('format=yuv420p');
        args.addAll(['-ss', (c.start.inMilliseconds / 1000).toStringAsFixed(3), '-t', (c.duration.inMilliseconds / 1000).toStringAsFixed(3), '-i', c.path]);
        // Every video is independently positioned on a black timeline canvas.
        // This makes overlapping clips deterministic: later clips are composited above earlier clips.
        final offset = c.timelineStart.inMilliseconds / 1000.0;
        filters.add('[$i:v]${vf.join(',')},setpts=PTS-STARTPTS+${offset.toStringAsFixed(3)}/TB[v$i]');
      }

      final durationSec = totalMs / 1000.0;
      filters.add('color=c=black:s=1280x720:r=30:d=${durationSec.toStringAsFixed(3)}[base]');
      var currentVideo = '[base]';
      for (var i = 0; i < videoClips.length; i++) {
        final out = '[comp$i]';
        filters.add('$currentVideo[v$i]overlay=0:0:eof_action=pass:shortest=0$out');
        currentVideo = out;
      }

      // Overlay-track images are composited after Video, then Text is composited last.
      final external = clips.where((c) => !c.isVideo && c.track == TrackType.audio && c.duration > Duration.zero).toList();
      final overlayClips = clips.where((c) => !c.isVideo && c.track == TrackType.overlay && c.duration > Duration.zero).toList();
      // Add external audio inputs before overlay inputs so their FFmpeg indexes stay deterministic.
      for (final c in external) {
        args.addAll(['-ss', (c.start.inMilliseconds / 1000).toStringAsFixed(3), '-t', (c.duration.inMilliseconds / 1000).toStringAsFixed(3), '-i', c.path]);
      }
      for (var i = 0; i < overlayClips.length; i++) {
        final c = overlayClips[i];
        args.addAll(['-loop', '1', '-t', (c.duration.inMilliseconds / 1000).toStringAsFixed(3), '-i', c.path]);
        final inputIndex = videoClips.length + external.length + i;
        final start = c.timelineStart.inMilliseconds / 1000.0;
        final end = (c.timelineStart + c.duration).inMilliseconds / 1000.0;
        final label = '[ov$i]';
        filters.add('[$inputIndex:v]scale=640:-1,format=rgba,setpts=PTS-STARTPTS$label');
        final out = '[ovf$i]';
        filters.add("$currentVideo$label overlay=(main_w-overlay_w)/2:(main_h-overlay_h)/2:enable='between(t,$start,$end)':eof_action=pass:shortest=0$out");
        currentVideo = out;
      }

      final textFilters = <String>[];
      for (final t in textItems) {
        final safeText = t.text.replaceAll('\\', '\\\\').replaceAll(':', '\\:').replaceAll("'", "\\'");
        textFilters.add("drawtext=fontfile=/system/fonts/Roboto-Regular.ttf:text='$safeText':fontsize=${t.fontSize.round()}:fontcolor=white:borderw=2:bordercolor=black:x=(w-text_w)*${t.x.clamp(0,1)}:y=(h-text_h)*${t.y.clamp(0,1)}:enable='between(t,${t.start.inMilliseconds/1000},${t.end.inMilliseconds/1000})'");
      }
      if (textFilters.isNotEmpty) {
        filters.add('$currentVideo${textFilters.join(',')}[vtext]');
        currentVideo = '[vtext]';
      }

      // Video-track audio is mixed independently and positioned at timelineStart.
      String? finalAudio;
      for (var i = 0; i < videoClips.length; i++) {
        finalAudio = null;
        // Audio is attached below after optional audio-stream probing.
      }
      final audioLabels = <String>[];
      for (var i = 0; i < videoClips.length; i++) {
        final c = videoClips[i];
        // Optional stream mapping is handled with FFmpeg's map syntax only when an audio stream exists.
        final probe = await FFmpegKit.executeWithArguments(['-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=index', '-of', 'csv=p=0', c.path]);
        final probeOutput = (await probe.getOutput() ?? '').trim();
        if (probeOutput.isEmpty) continue;
        var af = '[$i:a]volume=${c.volume.toStringAsFixed(3)}';
        if (c.fadeIn > 0) af += ',afade=t=in:st=0:d=${c.fadeIn.toStringAsFixed(3)}';
        if (c.fadeOut > 0 && c.fadeOut < c.duration.inMilliseconds / 1000) {
          final st = c.duration.inMilliseconds / 1000 - c.fadeOut;
          af += ',afade=t=out:st=${st.toStringAsFixed(3)}:d=${c.fadeOut.toStringAsFixed(3)}';
        }
        af += ',adelay=${c.timelineStart.inMilliseconds}|${c.timelineStart.inMilliseconds}[va$i]';
        filters.add(af);
        audioLabels.add('[va$i]');
      }
      for (var i = 0; i < external.length; i++) {
        final c = external[i];
        final inputIndex = videoClips.length + i;
        var af = '[$inputIndex:a]volume=${c.volume.toStringAsFixed(3)}';
        if (c.fadeIn > 0) af += ',afade=t=in:st=0:d=${c.fadeIn.toStringAsFixed(3)}';
        if (c.fadeOut > 0 && c.fadeOut < c.duration.inMilliseconds / 1000) {
          final st = c.duration.inMilliseconds / 1000 - c.fadeOut;
          af += ',afade=t=out:st=${st.toStringAsFixed(3)}:d=${c.fadeOut.toStringAsFixed(3)}';
        }
        af += ',adelay=${c.timelineStart.inMilliseconds}|${c.timelineStart.inMilliseconds}[ea$i]';
        filters.add(af);
        audioLabels.add('[ea$i]');
      }
      if (audioLabels.isNotEmpty) {
        filters.add('${audioLabels.join()}amix=inputs=${audioLabels.length}:duration=longest:dropout_transition=0,apad=pad_dur=${durationSec.toStringAsFixed(3)},atrim=duration=${durationSec.toStringAsFixed(3)}[mix]');
        finalAudio = '[mix]';
      }

      args.addAll(['-filter_complex', filters.join(';'), '-map', currentVideo]);
      if (finalAudio != null) args.addAll(['-map', finalAudio]);
      args.addAll(['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-r', '30', '-pix_fmt', 'yuv420p']);
      if (finalAudio != null) args.addAll(['-c:a', 'aac', '-b:a', '192k']);
      args.addAll(['-t', durationSec.toStringAsFixed(3), '-movflags', '+faststart', output]);

      final completer = Completer<dynamic>();
      final session = await FFmpegKit.executeWithArgumentsAsync(
        args,
        (session) async {
          if (!completer.isCompleted) completer.complete(session);
        },
        null,
        (statistics) {
          final ms = statistics.getTime();
          final progress = (ms / totalMs).clamp(0.0, 0.99).toDouble();
          if (mounted) setState(() { _renderProgress = progress; _renderStatus = 'Encoding ${(progress * 100).round()}%'; });
          _renderProgressNotifier.value = progress;
          _renderStatusNotifier.value = _renderStatus;
        },
      );
      _renderSessionId = session.getSessionId();
      if (mounted) setState(() => _renderStatus = 'Encoding…');
      _renderStatusNotifier.value = _renderStatus;
      final completed = await completer.future;
      final code = await completed.getReturnCode();
      if (ReturnCode.isCancel(code)) throw const _RenderCancelled();
      if (!ReturnCode.isSuccess(code)) throw Exception('FFmpeg render failed: ${await completed.getOutput()}');
      if (mounted) setState(() { _renderProgress = 1; _renderStatus = 'Finished'; });
      _renderProgressNotifier.value = 1;
      _renderStatusNotifier.value = 'Finished';
      if (timelinePreview) {
        final controller = VideoPlayerController.file(File(output));
        await controller.initialize();
        await player?.dispose();
        if (!mounted) { await controller.dispose(); return; }
        setState(() { player = controller; selected = videoClips.isEmpty ? selected : clips.indexOf(videoClips.first); });
        await controller.play();
      }
    } catch (e) {
      if (mounted) {
        setState(() { _renderProgress = 0; _renderStatus = e is _RenderCancelled ? 'Cancelled' : 'Render failed'; });
        _renderProgressNotifier.value = 0;
        _renderStatusNotifier.value = _renderStatus;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e is _RenderCancelled ? 'Render cancelled.' : 'Export failed: $e')));
      }
    } finally {
      if (mounted) setState(() { _rendering = false; _renderSessionId = null; });
      if (!timelinePreview && await File(output).exists()) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('MP4 export complete: $output')));
      }
    }
  }


  Future<void> saveProject() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = _loadedProjectPath ?? '${dir.path}/${_projectName.replaceAll(RegExp(r'[^a-zA-Z0-9_-]+'), '_')}.json';
    final file = File(path);
    final data = {
      'version': 6,
      'projectName': _projectName,
      'selected': selected,
      'selectedTrack': selectedTrack.name,
      'snapEnabled': snapEnabled,
      'timelineZoom': timelineZoom,
      'markersMs': markers.map((m) => m.inMilliseconds).toList(),
      'textItems': textItems.map((t) => {'text': t.text, 'startMs': t.start.inMilliseconds, 'endMs': t.end.inMilliseconds, 'x': t.x, 'y': t.y, 'fontSize': t.fontSize}).toList(),
      'clips': clips.map((c) => {
        'path': c.path, 'name': c.name, 'isVideo': c.isVideo, 'track': c.track.name,
        'sourceDurationMs': c.sourceDuration.inMilliseconds, 'startMs': c.start.inMilliseconds, 'endMs': c.end.inMilliseconds, 'timelineStartMs': c.timelineStart.inMilliseconds,
        'volume': c.volume, 'fadeIn': c.fadeIn, 'fadeOut': c.fadeOut, 'brightness': c.brightness, 'saturation': c.saturation, 'rotation': c.rotation, 'transition': c.transition,
      }).toList(),
    };
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    _loadedProjectPath = file.path;
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Project saved: ${file.path}')));
  }

  String time(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${d.inSeconds.remainder(60).toString().padLeft(2, '0')}';

  Widget tool(IconData icon, String text, VoidCallback? onTap) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: FilledButton.tonalIcon(
          onPressed: onTap,
          icon: Icon(icon, size: 18),
          label: Text(text),
        ),
      );

  void selectTrack(TrackType track) {
    setState(() => selectedTrack = track);
  }

  Widget _trackHeader(TrackType track) {
    final active = track == selectedTrack;
    final count = clips.where((c) => c.track == track).length;
    return InkWell(
      onTap: () => selectTrack(track),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 92,
        height: 58,
        margin: const EdgeInsets.only(right: 6),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF2A2040) : const Color(0xFF15151C),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: active ? const Color(0xFF8B5CF6) : Colors.white10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(track.icon, size: 18),
            const SizedBox(height: 2),
            Text(track.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            Text('$count clips', style: const TextStyle(fontSize: 9, color: Colors.white54)),
          ],
        ),
      ),
    );
  }

  Widget _clipTile(int i, double width) {
    final x = clips[i];
    final active = i == selected;
    return GestureDetector(
      onTap: () {
        setState(() => selected = i);
        loadPreview();
      },
      onDoubleTap: () => selectTrack(x.track),
      child: Container(
        width: width,
        height: 76,
        margin: const EdgeInsets.only(right: 6),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: active ? const Color(0xFF2A2040) : const Color(0xFF17171E),
          border: Border.all(
            color: active ? const Color(0xFF8B5CF6) : Colors.white10,
            width: active ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(x.isVideo ? Icons.video_file : Icons.image_outlined, size: 17),
              const SizedBox(width: 5),
              Expanded(child: Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
            ]),
            const Spacer(),
            Text('at ${time(x.timelineStart)} • ${time(x.duration)}', style: const TextStyle(fontSize: 10, color: Colors.white60)),
          ],
        ),
      ),
    );
  }

  Widget _timelineTrack(TrackType track) {
    final items = <int>[];
    for (var i = 0; i < clips.length; i++) {
      if (clips[i].track == track) items.add(i);
    }
    final totalMs = timelineDuration.inMilliseconds.toDouble().clamp(1000, double.infinity);
    final contentWidth = (totalMs / 1000 * 42 * timelineZoom).clamp(500.0, 5000.0);
    return SizedBox(
      height: 82,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _trackHeader(track),
          Expanded(
            child: items.isEmpty
                ? Container(
                    height: 58,
                    decoration: BoxDecoration(color: const Color(0xFF111117), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white10)),
                    alignment: Alignment.center,
                    child: Text('Tap ${track.label} to select this track', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  )
                : SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: contentWidth,
                      height: 76,
                      child: Stack(children: [
                        for (final i in items)
                          Positioned(
                            left: (clips[i].timelineStart.inMilliseconds / totalMs * contentWidth).clamp(0, contentWidth - 20),
                            top: 0,
                            child: _clipTile(i, (clips[i].duration.inMilliseconds / totalMs * contentWidth).clamp(70.0, contentWidth)),
                          ),
                      ]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _timelineRuler() {
    final total = timelineDuration.inMilliseconds.toDouble().clamp(1000, double.infinity);
    final width = (total / 1000 * 42 * timelineZoom).clamp(300.0, 5000.0);
    final playhead = player?.value.isInitialized == true ? player!.value.position : (current?.timelineStart ?? Duration.zero);
    return SizedBox(
      height: 32,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: width,
          child: Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(painter: _RulerPainter(totalMs: total)),
              ),
              for (final marker in markers)
                Positioned(
                  left: (marker.inMilliseconds / total * width).clamp(0, width - 2),
                  top: 0,
                  child: GestureDetector(
                    onTap: () => removeMarker(marker),
                    child: const Icon(Icons.location_on, size: 16),
                  ),
                ),
              Positioned(
                left: (playhead.inMilliseconds / total * width).clamp(0, width - 2),
                top: 0,
                bottom: 0,
                child: Container(width: 2, color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMultiTrackTimeline() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Text('Timeline', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(width: 10),
              FilterChip(
                selected: snapEnabled,
                onSelected: (v) => setState(() => snapEnabled = v),
                label: const Text('Snap'),
                avatar: const Icon(Icons.fit_screen, size: 15),
              ),
              const Spacer(),
              IconButton(tooltip: 'Add marker', onPressed: current == null ? null : addMarker, icon: const Icon(Icons.add_location_alt_outlined)),
              Text('${markers.length} markers', style: const TextStyle(fontSize: 11, color: Colors.white54)),
            ]),
            _timelineRuler(),
            _timelineTrack(TrackType.video),
            _timelineTrack(TrackType.overlay),
            _timelineTrack(TrackType.text),
            _timelineTrack(TrackType.audio),
            Row(children: [
              const Icon(Icons.zoom_out, size: 16),
              Expanded(
                child: Slider(
                  min: 0.6,
                  max: 2.2,
                  value: timelineZoom,
                  onChanged: (v) => setState(() => timelineZoom = v),
                ),
              ),
              const Icon(Icons.zoom_in, size: 16),
              const SizedBox(width: 6),
              Text('${(timelineZoom * 100).round()}%', style: const TextStyle(fontSize: 11, color: Colors.white60)),
            ]),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    player?.dispose();
    audioPlayer.dispose();
    _renderProgressNotifier.dispose();
    _renderStatusNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = current;
    final playerReady = player?.value.isInitialized == true;
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: _renameProject,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('VEdit Pro', style: TextStyle(fontWeight: FontWeight.w800)),
              Text(_projectName, style: const TextStyle(fontSize: 10, color: Colors.white54)),
            ],
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(onPressed: undo.isEmpty ? null : undoAction, icon: const Icon(Icons.undo)),
          IconButton(onPressed: redo.isEmpty ? null : redoAction, icon: const Icon(Icons.redo)),
          IconButton(onPressed: openProject, tooltip: 'Open project', icon: const Icon(Icons.folder_open_outlined)),
          IconButton(onPressed: clips.isEmpty ? null : saveProject, tooltip: 'Save project', icon: const Icon(Icons.save_outlined)),
        ],
      ),
      body: Column(children: [
        Expanded(
          flex: 5,
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white12),
            ),
            child: Center(
              child: c == null
                  ? const Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.movie_creation_outlined, size: 56),
                      SizedBox(height: 12),
                      Text('Import media to start editing')
                    ])
                  : Stack(alignment: Alignment.center, children: [
                      c.isVideo && playerReady
                          ? GestureDetector(
                              onTap: () {
                                player!.value.isPlaying ? player!.pause() : player!.play();
                                setState(() {});
                              },
                              child: AspectRatio(aspectRatio: player!.value.aspectRatio, child: VideoPlayer(player!)),
                            )
                          : Column(mainAxisSize: MainAxisSize.min, children: [
                              const Icon(Icons.image_outlined, size: 70),
                              const SizedBox(height: 8),
                              Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            ]),
                      ...textItems.where((t) => (player?.value.position ?? c.start) >= t.start && (player?.value.position ?? c.start) <= t.end).map((t) => Positioned.fill(
                        child: Align(alignment: Alignment(t.x * 2 - 1, t.y * 2 - 1), child: Text(t.text, style: TextStyle(fontSize: t.fontSize, fontWeight: FontWeight.w800, shadows: const [Shadow(blurRadius: 6)]))),
                      )),
                    ]),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(children: [
            Text(c == null ? '00:00' : time(c.timelineStart)),
            const Spacer(),
            Text(playerReady ? time(player!.value.position) : (c == null ? '00:00' : time(c.timelineStart + c.duration))),
            const Spacer(),
            Text(c == null ? '00:00' : time(c.timelineStart + c.duration)),
          ]),
        ),
        if (c != null && playerReady)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Slider(
              min: c.start.inMilliseconds.toDouble(),
              max: c.end.inMilliseconds.toDouble().clamp(c.start.inMilliseconds.toDouble() + 1, c.sourceDuration.inMilliseconds.toDouble()),
              value: player!.value.position.inMilliseconds.clamp(c.start.inMilliseconds, c.end.inMilliseconds).toDouble(),
              onChanged: (v) => seekPreview(Duration(milliseconds: v.round())),
            ),
          ),
        Expanded(
          flex: 4,
          child: SingleChildScrollView(
            child: _buildMultiTrackTimeline(),
          ),
        ),
        SafeArea(
          top: false,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 14),
            child: Row(children: [
              tool(Icons.add, 'Import', importMedia),
              tool(Icons.content_cut, 'Split', c == null ? null : split),
              tool(Icons.first_page, 'Trim In', c == null ? null : trimIn),
              tool(Icons.last_page, 'Trim Out', c == null ? null : trimOut),
              tool(Icons.copy, 'Duplicate', c == null ? null : duplicateSelected),
              tool(Icons.delete_outline, 'Delete', c == null ? null : deleteSelected),
              tool(Icons.chevron_left, 'Move Left', c == null ? null : () => moveSelected(-1)),
              tool(Icons.chevron_right, 'Move Right', c == null ? null : () => moveSelected(1)),
              tool(Icons.keyboard_arrow_left, 'Timeline -0.5s', c == null ? null : () => nudgeSelectedTimeline(-500)),
              tool(Icons.keyboard_arrow_right, 'Timeline +0.5s', c == null ? null : () => nudgeSelectedTimeline(500)),
              tool(Icons.schedule, 'Set Position', c == null ? null : setSelectedTimelineStart),
              tool(Icons.music_note, 'Audio', () { selectTrack(TrackType.audio); if (current != null && !current!.isVideo) toggleAudioPreview(); }),
              tool(Icons.tune, 'Audio Mix', c == null ? null : showAudioControls),
              tool(Icons.title, 'Text', editTextOverlay),
              tool(Icons.play_circle_outline, 'Timeline Preview', clips.any((x) => x.isVideo) ? () => exportMp4(timelinePreview: true) : null),
              tool(Icons.file_upload_outlined, 'Export MP4', clips.any((x) => x.isVideo) ? exportMp4 : null),
              tool(Icons.auto_awesome, 'Effects', c?.isVideo == true ? showEffects : null),
              tool(Icons.rotate_right, 'Rotate', c?.isVideo == true ? showEffects : null),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _RenderCancelled implements Exception {
  const _RenderCancelled();
}

class _RulerPainter extends CustomPainter {
  _RulerPainter({required this.totalMs});
  final double totalMs;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white24..strokeWidth = 1;
    final seconds = (totalMs / 1000).ceil();
    if (seconds <= 0) return;
    final pxPerSecond = size.width / seconds;
    for (var s = 0; s <= seconds; s++) {
      final x = s * pxPerSecond;
      canvas.drawLine(Offset(x, 18), Offset(x, s % 5 == 0 ? 8 : 12), paint);
      if (s % 5 == 0) {
        final tp = TextPainter(
          text: TextSpan(text: '${s}s', style: const TextStyle(fontSize: 9, color: Colors.white54)),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x + 2, 1));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RulerPainter oldDelegate) => oldDelegate.totalMs != totalMs;
}
