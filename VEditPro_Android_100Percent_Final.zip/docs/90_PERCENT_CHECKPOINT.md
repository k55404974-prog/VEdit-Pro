# VEdit Pro — 90% Checkpoint

This checkpoint continues from the 80% project and makes timeline positioning a real persisted concept.

## Real 90% work
- Added `Clip.timelineStart` separately from source trim `start/end`.
- Imported media is placed at the current timeline end.
- Timeline tiles are positioned by `timelineStart`, not simply packed in list order.
- Added real timeline nudge controls: -0.5s / +0.5s.
- Added a real “Set Position” dialog using seconds.
- Snap now targets timeline positions and timeline clip ends.
- Split keeps the second piece at the correct timeline position.
- Duplicate places the copy after the selected clip on the timeline.
- Project JSON is now version 6 and persists `timelineStartMs`.
- Video-track export uses timeline positions and creates real black gaps between clips.
- Existing effects, transitions, text, overlay compositing, external audio mixing, save/open and rendered Timeline Preview are retained.
- Overlay and external audio timing use `timelineStart`.

## Important limitation
The editor still treats overlapping Video-track clips conservatively during export; the next milestone should add a dedicated overlap/compositing policy and stronger real-time timeline playback.

Flutter/Dart are not installed in the build environment used for this checkpoint, so no Flutter analyzer run or APK build could be verified here.
