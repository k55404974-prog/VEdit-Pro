# VEdit Pro — 70% Checkpoint

This milestone continues from the verified 60% source checkpoint and adds real clip effects and transitions to the Android FFmpeg export pipeline.

## Implemented
- Per-video-clip brightness adjustment using FFmpeg `eq`.
- Per-video-clip saturation adjustment using FFmpeg `eq`.
- Real 0/90/180/270 degree rotation during export.
- Real cross-fade video transitions between adjacent Video-track clips using FFmpeg `xfade`.
- Matching audio cross-fades for Video-track clips using FFmpeg `acrossfade`.
- External Audio-track mixing remains supported with volume, fade-in, fade-out and timeline delay.
- Text overlays remain rendered with FFmpeg `drawtext`.
- Effect/transition values persist in project JSON (version 5).
- Undo/redo snapshots continue to preserve clip settings because Clip.copyWith now includes all effect fields.
- Existing 50% and 60% functionality is preserved.

## Important limitation
Flutter/Dart is not installed in the execution environment, so this checkpoint could not be compiled or APK-tested here. The implementation is source-level real FFmpeg integration; local Android build remains the required validation step.
