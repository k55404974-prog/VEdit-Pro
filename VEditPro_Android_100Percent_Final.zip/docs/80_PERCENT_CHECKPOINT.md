# VEdit Pro — 80% Checkpoint

This milestone continues from the 70% source checkpoint and adds a real rendered multi-track preview layer.

## Implemented
- Real **Timeline Preview** action: FFmpeg renders the current Video track, transitions, effects, audio mix, text overlays and Overlay-track still images into a playable MP4 preview.
- Overlay-track still images are actual FFmpeg inputs and are composited over the rendered video only for their timeline interval.
- Preview output is loaded into `video_player` and starts playback after rendering; this is not a simulated UI preview.
- Existing MP4 export remains available separately.
- Existing 50%, 60% and 70% features remain in the source.

## Important limitation
Flutter/Dart is not installed in the execution environment, so this checkpoint could not be compiled or APK-tested here. The source uses real FFmpeg commands and `video_player`; local Android build/testing remains required.
