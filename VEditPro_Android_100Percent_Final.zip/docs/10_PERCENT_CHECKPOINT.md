# VEdit Pro — 10% checkpoint

We are keeping this milestone intentionally small.

## Added in this checkpoint
- Timeline preview scrubber
- Current playhead time display
- Scrubbing constrained to the selected clip's trim range
- Local project JSON save action
- Save button in the editor header

## Still not counted as complete
- Frame-accurate encoded rendering/export
- Audio mixing
- Text rendering
- Effects/transitions
- Keyframes
- AI/VFX

Stop here for the requested 10% target and test this build before expanding it.
