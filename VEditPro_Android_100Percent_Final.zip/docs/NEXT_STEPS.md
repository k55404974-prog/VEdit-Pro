# Next VEdit Pro layers

Current: 50% checkpoint.

Next priority layers:
1. synchronized multi-track playback/mixing
2. real MP4 render/export pipeline
3. crop/resize/rotate/flip and transform properties
4. audio fade application in renderer and waveform UI
5. text animation/style/keyframes
6. effects/transitions/color adjustments
7. keyframes and motion curves
8. cutout/masks/tracking
9. AI
10. professional VFX/compositing
